cd $1
pip freeze > requirements.txt
cd ..
