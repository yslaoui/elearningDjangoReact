# Run a django project called $1 where cd is a ../$1
python3 $1/manage.py runserver 127.0.0.1:8080

