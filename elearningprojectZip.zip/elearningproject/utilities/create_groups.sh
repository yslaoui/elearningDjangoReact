python3 $1/manage.py create_groups
