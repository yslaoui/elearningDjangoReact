python3 $1/manage.py createsuperuser

